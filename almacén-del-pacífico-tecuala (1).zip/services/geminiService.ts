import { GoogleGenAI, Type } from "@google/genai";
import { Region, SearchResult } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const verifyPrices = async (
  query: string,
  region: Region
): Promise<SearchResult> => {
  try {
    const prompt = `
      Actúa como un experto gerente de ventas y logística de Grupo Modelo para la zona del Pacífico de México (Nayarit, Sinaloa, Jalisco).
      
      OBJETIVO: Consultar precios de mercado actuales para: "${query}" en ${region}.
      
      IMPORTANTE: Si la búsqueda "${query}" es un CÓDIGO (numérico, SKU, UPC o código corto de almacén), identifica primero a qué producto corresponde dentro del portafolio de Grupo Modelo y procede a cotizarlo.
      
      CATÁLOGO A CONSIDERAR (Si aplica a la búsqueda):
      - Nacionales: Corona (Extra, Light, Cero), Victoria, Modelo (Especial, Negra, Trigo), Pacífico (Clara, Light, Suave), Barrilito, Montejo, León, Estrella.
      - Importadas/Premium: Stella Artois, Michelob Ultra (todas sus variedades), Budweiser, Bud Light, Miller High Life.
      
      INSTRUCCIONES DE PRECIOS:
      Busca y desglosa la información en dos niveles (cuando sea posible):
      1. PRECIO AGENCIA/MAYOREO: El costo estimado de compra por volumen (Caja, Cartón, Charola) directo en Agencia o Depósito mayorista.
      2. PRECIO MODELORAMA/MENUDEO: El precio de venta al público sugerido (Unitario, Six Pack, o por envase).
      
      PRESENTACIONES CLAVE:
      - Botes: 330ml, 355ml, 473ml (Latón), 710ml.
      - Vidrio: Cuartito (190/210ml), Media (355ml), Familiar (940ml/1L), Mega/Ballena/Ballenón (1.2L).
      
      Si no encuentras el dato exacto de HOY, genera un estimado lógico basado en los precios vigentes de Grupo Modelo en la región ${region}, mencionando si es un precio de lista oficial o un precio de mercado promedio.
      
      Devuelve los resultados estrictamente en formato JSON.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            products: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  productName: { type: Type.STRING, description: "Marca y Submarca (Ej: Corona Extra, Michelob Ultra)" },
                  presentation: { type: Type.STRING, description: "Envase y medida (Ej: Latón 473ml, Ballena 940ml)" },
                  packType: { type: Type.STRING, description: "Unidad de cotización (Ej: Cartón 20 botellas, Charola 24 latas, Six Pack)" },
                  estimatedPrice: { type: Type.NUMBER, description: "Precio estimado en Pesos Mexicanos" },
                  currency: { type: Type.STRING, description: "MXN" },
                  notes: { type: Type.STRING, description: "Especifique si es Precio Agencia (Costo) o Modelorama (Venta), y la fuente referencial." }
                },
                required: ["productName", "presentation", "packType", "estimatedPrice", "currency", "notes"]
              }
            }
          },
          required: ["products"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No se generó respuesta de la IA.");
    }

    const data = JSON.parse(text);
    
    // Extract grounding metadata if available
    const groundingUrls: Array<{ title: string; uri: string }> = [];
    if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
      response.candidates[0].groundingMetadata.groundingChunks.forEach((chunk: any) => {
        if (chunk.web?.uri && chunk.web?.title) {
          groundingUrls.push({
            title: chunk.web.title,
            uri: chunk.web.uri
          });
        }
      });
    }

    return {
      products: data.products || [],
      groundingUrls
    };

  } catch (error) {
    console.error("Error consultando precios:", error);
    throw error;
  }
};