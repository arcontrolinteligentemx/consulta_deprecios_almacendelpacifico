import React from 'react';
import { ProductPrice } from '../types';

interface ProductListProps {
  products: ProductPrice[];
}

const ProductList: React.FC<ProductListProps> = ({ products }) => {
  if (products.length === 0) {
    return (
      <div className="text-center py-12 text-slate-500">
        No se encontraron resultados. Intenta con otra búsqueda.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product, index) => (
        <div 
          key={index} 
          className="bg-white rounded-xl shadow-md overflow-hidden border border-slate-200 hover:shadow-lg transition-shadow duration-300 flex flex-col"
        >
          <div className="h-2 bg-gradient-to-r from-blue-600 to-yellow-400" />
          <div className="p-6 flex-1 flex flex-col">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-bold text-slate-800">{product.productName}</h3>
              <span className="text-xs font-bold px-2 py-1 bg-blue-100 text-blue-800 rounded uppercase tracking-wider">
                {product.currency}
              </span>
            </div>
            
            <p className="text-slate-500 text-sm mb-4 font-medium">{product.presentation} - {product.packType}</p>
            
            <div className="mt-auto">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold text-slate-900">${product.estimatedPrice.toFixed(2)}</span>
                <span className="text-sm text-slate-500">aprox.</span>
              </div>
              
              <div className="mt-4 pt-4 border-t border-slate-100">
                <p className="text-xs text-slate-500 italic">
                  <span className="font-semibold text-slate-700">Nota:</span> {product.notes}
                </p>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductList;