import React from 'react';
import { Region } from '../types';

interface RegionSelectorProps {
  selectedRegion: Region;
  onRegionChange: (region: Region) => void;
}

const RegionSelector: React.FC<RegionSelectorProps> = ({ selectedRegion, onRegionChange }) => {
  return (
    <div className="flex flex-col sm:flex-row gap-4 items-center bg-white p-4 rounded-lg shadow-sm border border-slate-200">
      <label className="text-slate-700 font-semibold whitespace-nowrap">
        Zona de Consulta:
      </label>
      <div className="flex gap-2 w-full sm:w-auto">
        {Object.values(Region).map((region) => (
          <button
            key={region}
            onClick={() => onRegionChange(region)}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
              selectedRegion === region
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {region}
          </button>
        ))}
      </div>
    </div>
  );
};

export default RegionSelector;